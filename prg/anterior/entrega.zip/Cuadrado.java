class Cuadrado {
	public static void main (String [] args) {
		int numero = 2; 		// Changed , to ;
		int cuad = numero * numero;	// added int and changed ú
		System.out.printf("El cuadrado de %d es: %d \n", numero, cuad);	
	}
}
