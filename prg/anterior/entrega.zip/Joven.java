public class Joven {
	public static void main (String [] args) {

	}
}
