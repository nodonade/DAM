public class MeGusta {
	public static void main (String [] args) {
		System.out.printf("Me gusta la programación\nCada día más\n");
	}
}
