public class LongitudCircunferencia {
	public static void main (String [] args) {
		int radio = 3;
		double longitud = Math.PI * radio * 2;
		
		System.out.printf("La longitud de una circunferencia de %d metros de radio es %f \n", radio, longitud);
	}
}
