public class Area {
	public static void main (String [] args) {
		double radio = 5.2;
		double area = Math.PI * radio * radio;

		System.out.printf("El area de una circunferencia de radio %f es %f \n", radio, area);
	}
}
