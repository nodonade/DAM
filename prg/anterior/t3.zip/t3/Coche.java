
/*
 * Description of program
 *
 * @author Ignacio E. Loyola @nodonade.com
 * @version 0.1
 *
 */


public class Coche {
	private String marca, modelo;
	public Coche( ) {
		marca = "Volkswagen";
		modelo = "Polo";
	}
	public Coche( String ma, String mo ) {
		marca = ma;
		modelo = mo;
	}

	public static void main (String [] args) {

	}
}
