
/*
 * Description of program
 *
 * @author Ignacio E. Loyola @nodonade.com
 * @version 0.1
 *
 */

import java.util.*;

public class Placeholder {
	public static void main (String [] args) {
		Scanner kbd = new Scanner(System.in);

	}
}
