public class Ejercicio2 {
	public static void main (String [] args){
		int i, j, filas=4;
		for (i = 1; i <= filas; i++){
			if ((i == 1) || (i == filas))
			for (j = 1; j <= filas; j++)
				System.out.print("*");
			else
			System.out.print("*");
		System.out.println("");
		}
	}
}
