
/*
 * Description of program
 *
 * @author Ignacio E. Loyola @nodonade.com
 * @version 0.1
 *
 */

import java.util.*;

public class Ejer5 {
	public static void main (String [] args) {
		int x = 1;

		System.out.printf("a es %s \n", x % 2 == 0 ? "par" : "impar");
	}
}
