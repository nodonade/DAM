
/*
 * Description of program
 *
 * @author Ignacio E. Loyola @nodonade.com
 * @version 0.1
 *
 */

import java.util.*;

public class Ejer3 {
	public static void main (String [] args) {
		int n = 13;

		n += 77; n -= 3; n *= 2;
	}
}
