/*
 * Ejercicio 2
 *
 * @author Ignacio E. Loyola @nodonade.com
 * @version 0.1
 *
 */

import java.util.*;

public class Ejer2 {
	public static void main (String [] args) {
		int x = 1, y = 2; double n = 22.02, m = 50.05;

		System.out.printf(" x + y = %d, n - m = %.02f\n", x + y, n - m);
	}
}
