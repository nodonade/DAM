
/*
 * Description of program
 *
 * @author Ignacio E. Loyola @nodonade.com
 * @version 0.1
 *
 */

import java.util.*;

public class Ejer6 {
	public static void main (String [] args) {
		int b = -3;

		System.out.printf(" b (%d) es %s\n", b, b < 0 ? "negativo" : "positivo");
	}
}
